document.addEventListener('DOMContentLoaded', function () {
    var flipButtons = document.querySelectorAll('.flip-button');
    flipButtons.forEach(function (button) {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            var flipContainer = document.querySelector('.flip-container');
            flipContainer.style.transform = flipContainer.style.transform === 'rotateY(180deg)' ? 'rotateY(0deg)' : 'rotateY(180deg)';
        });
    });
});