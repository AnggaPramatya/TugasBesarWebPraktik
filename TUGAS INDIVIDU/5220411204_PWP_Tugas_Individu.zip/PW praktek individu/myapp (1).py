# TRIFONIO ANGGA PRAMATYA
# 5220411204

from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_mysqldb import MySQL
from werkzeug.security import check_password_hash, generate_password_hash 


app = Flask(__name__)

app.secret_key = "kodeapaa"
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'flaskmysql'

#init mysql
mysql = MySQL(app)


@app.route('/')
def beranda():
    if 'loggedin' in session:
        return render_template('beranda.html')
    return redirect(url_for('login1'))


@app.route("/login1", methods=('GET', 'POST'))
def login1():
    if request.method == 'POST':
        email = request.form['username']
        password = request.form['password']

        #cek data username
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM users WHERE username=%s', (email, ))
        akun = cursor.fetchone()
        if akun is None:
            flash('Login Gagal, Cek Kembali Username Anda', 'danger')
        elif not (akun[2], password):
            flash('Login Gagal, Cek Kembali Password Anda', 'danger')
        else:
            session['loggedin'] = True
            session['username'] = akun[1]
            return redirect(url_for('beranda'))
    return render_template('login1.html')


@app.route("/register", methods=('GET', 'POST'))
def uwi():
    if request.method == "POST":
        Username = request.form['username']
        Email = request.form['email']
        Password = request.form['password']

        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM users WHERE username=%s OR email=%s',(Username, Email))
        akun = cursor.fetchone()

        if akun is None:
            cursor.execute('INSERT INTO users VALUES (NULL, %s, %s, %s)', (Username, Password, Email))
            mysql.connection.commit()
            cursor.close()           
            flash('register berhasil', 'succes')
        else:
            flash('Username atau Email sudah ada', 'danger')
                  
    return render_template("register.html")
 

@app.route("/logout")
def logout():
    session.pop('loggedin', None)
    session.pop('username', None)
    return redirect(url_for('login1'))

@app.route('/about')
def about():
    return render_template('about.html')


if __name__ == "__main__":
    app.run(debug=True)
